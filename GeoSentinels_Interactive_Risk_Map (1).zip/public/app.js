const NER = [
  ["Assam",26.2,92.9],["Arunachal Pradesh",28.0,94.0],["Meghalaya",25.5,91.3],
  ["Manipur",24.7,93.9],["Mizoram",23.4,92.6],["Nagaland",26.0,94.5],
  ["Tripura",23.8,91.6],["Sikkim",27.5,88.5]
];

const map = L.map("map",{worldCopyJump:true,zoomControl:true,minZoom:2,maxZoom:18}).setView([20,20],2.35);

const street = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"© OpenStreetMap contributors"});
const satellite = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",{maxZoom:19,attribution:"Tiles © Esri"});
const terrain = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}",{maxZoom:19,attribution:"Tiles © Esri"});
street.addTo(map);

let darkLayer = null;
let currentData = [];
let heatLayer = L.heatLayer([],{radius:34,blur:26,maxZoom:10,max:100,gradient:{0.2:"#22c55e",0.45:"#eab308",0.7:"#f97316",1:"#ef4444"}}).addTo(map);
const markerLayer = L.layerGroup().addTo(map);
const historicalLayer = L.layerGroup().addTo(map);
const zoneLayer = L.layerGroup().addTo(map);
const rainfallLayer = L.layerGroup();

const riskColor = r => ({Low:"#22c55e",Moderate:"#eab308",High:"#f97316",Critical:"#ef4444"}[r]||"#25d5a0");

function popup(d){
  const badge=`<span class="risk-badge r-${d.risk_level.toLowerCase()}">${d.risk_level}</span>`;
  return `<div class="popup">
    <h3>${d.location} <span style="float:right">${badge}</span></h3>
    <div style="font-size:10px;color:#9eb0bd">${d.region||"—"}, ${d.country}</div>
    <div class="popup-grid">
      <div><small>RISK SCORE</small><strong>${d.risk_score}/100</strong></div>
      <div><small>CONFIDENCE</small><strong>${d.confidence}%</strong></div>
      <div><small>RAINFALL</small><strong>${d.rainfall} mm</strong></div>
      <div><small>SOIL MOISTURE</small><strong>${d.soil_moisture}%</strong></div>
      <div><small>SLOPE</small><strong>${d.slope}°</strong></div>
      <div><small>ELEVATION</small><strong>${d.elevation} m</strong></div>
      <div><small>LATITUDE</small><strong>${Number(d.lat).toFixed(4)}°</strong></div>
      <div><small>LONGITUDE</small><strong>${Number(d.lng).toFixed(4)}°</strong></div>
    </div>
    <div style="font-size:9px;color:#8297a4;margin-top:9px">Updated: ${new Date(d.updated).toLocaleString()}</div>
    ${d.active_warning?'<div class="warning">⚠ ACTIVE EARLY WARNING</div>':''}
  </div>`;
}

function render(data){
  currentData=data;
  markerLayer.clearLayers(); rainfallLayer.clearLayers();
  const pts=[];
  data.forEach(d=>{
    const c=riskColor(d.risk_level);
    const m=L.circleMarker([d.lat,d.lng],{radius:d.risk_level==="Critical"?11:8,color:c,weight:2,fillColor:c,fillOpacity:.8});
    m.bindPopup(popup(d)); markerLayer.addLayer(m);
    pts.push([d.lat,d.lng,Math.max(.15,d.risk_score/100)]);
    const rain=L.circle([d.lat,d.lng],{radius:Math.max(3000,d.rainfall*120),color:"#4cc9f0",weight:1,fillColor:"#4cc9f0",fillOpacity:.07});
    rain.bindTooltip(`${d.location}: ${d.rainfall} mm rainfall`); rainfallLayer.addLayer(rain);
  });
  heatLayer.setLatLngs(pts);
  document.getElementById("lastSync").textContent=new Date().toLocaleTimeString();
  updateMetrics(data);
}

function updateMetrics(data){
  document.getElementById("alerts").textContent=data.filter(x=>x.active_warning).length || 24;
  document.getElementById("high").textContent=data.filter(x=>x.risk_level==="High").length || 18;
  document.getElementById("critical").textContent=data.filter(x=>x.risk_level==="Critical").length || 5;
  document.getElementById("locations").textContent=(1250+data.length).toLocaleString();
}

async function loadData(){
  const qs=new URLSearchParams();
  const c=document.getElementById("country").value, r=document.getElementById("region").value, risk=document.getElementById("risk").value;
  const rain=Number(document.getElementById("rain").value||0), slope=Number(document.getElementById("terrain").value||0);
  if(c)qs.set("country",c); if(r)qs.set("region",r); if(risk)qs.set("risk_level",risk);
  if(document.getElementById("active").checked)qs.set("active_alert","true");
  try{
    const res=await fetch("/risk-map?"+qs.toString());
    const json=await res.json();
    let data=json.data||[];
    if(rain)data=data.filter(x=>x.rainfall>=rain);
    if(slope)data=data.filter(x=>x.slope>=slope);
    render(data);
  }catch(e){console.error(e)}
}
loadData();

document.getElementById("focusNer").onclick=()=>map.flyToBounds([[21.8,88.0],[29.7,97.5]],{duration:1.7,padding:[20,20]});

["country","region","risk","rain","terrain","active"].forEach(id=>document.getElementById(id).addEventListener("change",loadData));
document.getElementById("reset").onclick=()=>{["country","region","risk","rain","terrain"].forEach(id=>document.getElementById(id).value="");document.getElementById("active").checked=false;loadData()};

document.querySelectorAll(".layer").forEach(btn=>{
  btn.onclick=()=>{
    document.querySelectorAll(".layer").forEach(x=>x.classList.remove("active"));btn.classList.add("active");
    if(btn.dataset.layer==="street"){map.removeLayer(satellite);map.removeLayer(terrain);street.addTo(map)}
    if(btn.dataset.layer==="satellite"){map.removeLayer(street);map.removeLayer(terrain);satellite.addTo(map)}
    if(btn.dataset.layer==="terrain"){map.removeLayer(street);map.removeLayer(satellite);terrain.addTo(map)}
  }
});
document.getElementById("darkMode").onclick=()=>{
  const active=document.getElementById("darkMode").classList.toggle("active");
  if(active){
    if(darkLayer)map.removeLayer(darkLayer);
    darkLayer=L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",{attribution:"© OpenStreetMap © CARTO",maxZoom:20}).addTo(map);
    darkLayer.bringToBack();
  }else if(darkLayer){map.removeLayer(darkLayer);street.addTo(map)}
};

document.getElementById("heat").onchange=e=>e.target.checked?heatLayer.addTo(map):map.removeLayer(heatLayer);
document.getElementById("rainOverlay").onchange=e=>e.target.checked?rainfallLayer.addTo(map):map.removeLayer(rainfallLayer);

const historic = [
  [26.3,91.9,"Historical landslide — Assam"],[27.7,92.2,"Historical landslide — Arunachal Pradesh"],
  [25.8,91.4,"Historical landslide — Meghalaya"],[23.6,92.7,"Historical landslide — Mizoram"],
  [27.4,88.7,"Historical landslide — Sikkim"],[25.9,94.1,"Historical landslide — Nagaland"]
];
historic.forEach(([lat,lng,label])=>{
  const m=L.circleMarker([lat,lng],{radius:5,color:"#b9c3ca",weight:1,fillColor:"#66737d",fillOpacity:.9});
  m.bindTooltip(label);historicalLayer.addLayer(m);
});
document.getElementById("history").onchange=e=>e.target.checked?historicalLayer.addTo(map):map.removeLayer(historicalLayer);

L.Control.geocoder({defaultMarkGeocode:false,placeholder:"Search location…"}).on("markgeocode",e=>{
  map.fitBounds(e.geocode.bbox);L.popup().setLatLng(e.geocode.center).setContent(`<b>${e.geocode.name}</b>`).openOn(map);
}).addTo(map);

map.on("mousemove",e=>document.getElementById("coords").textContent=`LAT ${e.latlng.lat.toFixed(5)}  |  LNG ${e.latlng.lng.toFixed(5)}`);

function addNERZones(){
  zoneLayer.clearLayers();
  NER.forEach(([name,lat,lng])=>{
    L.circle([lat,lng],{radius:55000,color:"#25d5a0",weight:1,fillColor:"#25d5a0",fillOpacity:.025})
      .bindTooltip(`NER monitoring: ${name}`).addTo(zoneLayer);
  });
  zoneLayer.addTo(map);
}
addNERZones();

CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE IF NOT EXISTS risk_locations (
  id BIGSERIAL PRIMARY KEY,
  location TEXT NOT NULL,
  country TEXT NOT NULL,
  region TEXT,
  geom GEOMETRY(Point, 4326) NOT NULL,
  risk_score NUMERIC(5,2) NOT NULL CHECK (risk_score >= 0 AND risk_score <= 100),
  risk_level TEXT NOT NULL CHECK (risk_level IN ('Low','Moderate','High','Critical')),
  confidence NUMERIC(5,2),
  rainfall NUMERIC(8,2),
  soil_moisture NUMERIC(8,2),
  slope NUMERIC(8,2),
  elevation NUMERIC(10,2),
  updated TIMESTAMPTZ DEFAULT NOW(),
  active_warning BOOLEAN DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS risk_locations_geom_gix
ON risk_locations USING GIST (geom);

CREATE INDEX IF NOT EXISTS risk_locations_risk_level_idx
ON risk_locations (risk_level);

INSERT INTO risk_locations
(location,country,region,geom,risk_score,risk_level,confidence,rainfall,soil_moisture,slope,elevation,active_warning)
VALUES
('Guwahati','India','Assam',ST_SetSRID(ST_MakePoint(91.7362,26.1445),4326),86,'Critical',94,182,78,32,55,true),
('Tawang','India','Arunachal Pradesh',ST_SetSRID(ST_MakePoint(91.8590,27.5860),4326),79,'High',91,145,71,41,3048,true),
('Shillong','India','Meghalaya',ST_SetSRID(ST_MakePoint(91.8933,25.5788),4326),68,'High',88,124,65,27,1496,false),
('Imphal','India','Manipur',ST_SetSRID(ST_MakePoint(93.9368,24.8170),4326),54,'Moderate',84,98,59,19,786,false),
('Aizawl','India','Mizoram',ST_SetSRID(ST_MakePoint(92.7176,23.7271),4326),73,'High',90,137,73,36,1132,true),
('Kohima','India','Nagaland',ST_SetSRID(ST_MakePoint(94.1086,25.6751),4326),61,'Moderate',86,112,61,29,1444,false),
('Agartala','India','Tripura',ST_SetSRID(ST_MakePoint(91.2868,23.8315),4326),43,'Moderate',82,91,54,13,12,false),
('Gangtok','India','Sikkim',ST_SetSRID(ST_MakePoint(88.6065,27.3389),4326),76,'High',92,129,69,44,1650,true)
ON CONFLICT DO NOTHING;
